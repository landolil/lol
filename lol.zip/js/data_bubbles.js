const bubbleImages = [
    'bubbles/bubbles.gif',

    // Add more bubble images as needed
];